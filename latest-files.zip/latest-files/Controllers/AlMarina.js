const xlsx = require("xlsx");
const fs = require('fs');
const path = require("path");

const propertyFileType = require('../propertyFile/propertyType');
const plotsToDeactivate = require('../propertyFile/deActivate');

const AlMarina = require("../DBSchema/models");

class AlMarinaController {
    // funtion for the processing of the file
  async extractDataFromFile(req, res) {
    if (!req.file) {
      return res.status(400).json({ error: CONSTANTS.MESSAGES.NOT_FOUND });
    }

    try {
      const filePath = path.resolve(req.file.path);
      const workbook = xlsx.readFile(filePath);
      const sheetName = workbook.SheetNames[0]; // Get first sheet
      const sheet = workbook.Sheets[sheetName];
      let data = xlsx.utils.sheet_to_json(sheet); // Convert to JSON

   

  // Define the output file path
  //const outputPath = path.join(__dirname, '../output', 'extractedData.js');

   // Ensure output directory exists
  //fs.mkdirSync(path.dirname(outputPath), { recursive: true });

  // Write JSON data to file
  // fs.writeFileSync(outputPath, JSON.stringify(data, null, 2), 'utf8');
      

       let previousBlockNumber = null;
      // const plotsToDeactivate = [
      //   742, 748, 849, 891, 892,
      //   451, 452, 453, 454, 455, 456, 457, 458, 459, 460,
      //   461, 462, 463, 464, 465, 467, 468, 469, 470, 471,
      //   472, 473, 474, 475, 476, 478, 479, 480, 481, 482,
      //   518, 520, 522, 524,
      //   546, 547, 548, 549, 550, 551, 552, 553, 554, 555,
      //   556, 557, 558, 559, 560, 561,
      //   906, 907, 908,
      //   278, 279, 280, 281, 282, 283, 284,
      //   901, 902, 903, 904, 905,
      //   295, 298,
      //   328,
      //   371,
      //   897, 898, 899, 900,
      //   882
      // ];
      // // Transform data

      // Use the data




      data = data.map((item) => {
        const block_number = item["رقم البلك"] !== undefined ? item["رقم البلك"] : previousBlockNumber;
        if (block_number !== undefined) {
          previousBlockNumber = block_number;
        }
        const plot_number = item["رقم القطعة "];

        const isDeactivated = plotsToDeactivate.some(p => p.plot_number === Number(plot_number));

       
          // Find matching property_type
  const propertyTypeMatch = propertyFileType.find(
    (p) => p.plot_number === Number(plot_number)
  );


        return {
          ...item,
          west: item.الغرب,
          east: item["الشرق "],
          north: item.الشمال,
          south: item["الجنوب "],
          total_area: item[" المساحة الاجمالية "],
          usage: item.الاستخدام,
          block_number,
          plot_number,
         property_type: propertyTypeMatch ? propertyTypeMatch.property_type : '--',
          isActivePlot: !isDeactivated
        };
      });




      // First update matching plots to isActivePlot = false (in case they already exist)
      // const deactivated = await AlMarina.updateMany(
      //   { plot_number: { $in: plotsToDeactivate.map(String) } },
      //   { $set: { isActivePlot: false } }
      // );
      // console.log(`${deactivated.modifiedCount} plots deactivated.`);
      // Insert new data

      const inactivePlots = await AlMarina.find({ isActivePlot: false });

      console.log(inactivePlots.length);


      const result = await AlMarina.create(data);
      if (result.length === 0) {
        return res.status(400).json({ error: { insertedDocs: [] } });
      }
      return res.status(200).json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ error: error });
    }
  }

  // function for get data from db
  
  async getAlMarinaData(req, res) {
    const alMarina = await AlMarina.find();
    res.json({ data: alMarina });
  }
}

module.exports = new AlMarinaController();
