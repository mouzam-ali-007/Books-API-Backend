module.exports = function generateContactEmail(data) {
    return `
      <div style="font-family: Arial, sans-serif; padding: 20px;">
        <h2 style="color: #2d3e50;">Thank you for contacting us!</h2>
        <p>Here are the details you submitted:</p>
        <table style="width: 100%; border-collapse: collapse;">
          <tr><td><strong>First Name:</strong></td><td>${data.firstName || "-" }</td></tr>
          <tr><td><strong>Last Name:</strong></td><td>${data.lastName || "-"}</td></tr>
          <tr><td><strong>Email:</strong></td><td>${data.email || "-"}</td></tr>
          <tr><td><strong>Phone:</strong></td><td>${data.phone || "-"}</td></tr>
          <tr><td><strong>Residence:</strong></td><td>${data.residence || "-"}</td></tr>
          <tr><td><strong>Nationality:</strong></td><td>${data.nationality || "-"}</td></tr>
          <tr><td><strong>Message:</strong></td><td>${data.message || "-"}</td></tr>

           <tr><td><strong>Property URL:</strong></td><td>${data.propertyURL || "-"}</td></tr>
        </table>
        <p style="margin-top: 20px;">We’ll get back to you soon.</p>
      </div>
    `;
  };