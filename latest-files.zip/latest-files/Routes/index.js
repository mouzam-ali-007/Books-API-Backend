const express = require("express");
const multer = require('multer');

const AlMarinaController = require("../Controllers/AlMarina");
const contactController = require("../Controllers/contact.controller");



const router = express.Router();

router.get("/", (req, res) => {
  res.send("Hello, Al-marina");

});


// Upload Excel/CSV file

const upload = multer({ dest: 'uploads/' });
router.post('/uploadData', upload.single('file'), AlMarinaController.extractDataFromFile);


// Get Al Marina data

router.get('/getAlMarinaData',  AlMarinaController.getAlMarinaData);


// Contact Form submission route
router.post('/contact', contactController.createContact);

// Get Al  contacts

router.get('/getAllContact',  contactController.getAllContact);

module.exports = router;
 