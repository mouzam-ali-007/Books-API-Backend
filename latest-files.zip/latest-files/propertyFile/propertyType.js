/*
 LIST OF DE PROPERTY TYPES
*/

const propertyFileType =[
  {
    "plot_number": 699,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 700,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 701,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 702,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 703,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 704,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 705,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 706,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 707,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 708,
    "property_type": "Eastern Municipality"
  },
  {
    "plot_number": 709,
    "property_type": "Eastern Municipality"
  },
  {
    "plot_number": 710,
    "property_type": "Eastern Municipality"
  },
  {
    "plot_number": 711,
    "property_type": "Eastern Municipality"
  },
  {
    "plot_number": 712,
    "property_type": "Eastern Municipality"
  },
  {
    "plot_number": 713,
    "property_type": "Eastern Municipality"
  },
  {
    "plot_number": 714,
    "property_type": "Eastern Municipality"
  },
  {
    "plot_number": 715,
    "property_type": "Residential"
  },
  {
    "plot_number": 716,
    "property_type": "Residential"
  },
  {
    "plot_number": 717,
    "property_type": "Residential"
  },
  {
    "plot_number": 718,
    "property_type": "Residential"
  },
  {
    "plot_number": 719,
    "property_type": "Residential"
  },
  {
    "plot_number": 720,
    "property_type": "Residential"
  },
  {
    "plot_number": 721,
    "property_type": "Residential"
  },
  {
    "plot_number": 722,
    "property_type": "Residential"
  },
  {
    "plot_number": 723,
    "property_type": "Residential"
  },
  {
    "plot_number": 724,
    "property_type": "Residential"
  },
  {
    "plot_number": 725,
    "property_type": "Residential"
  },
  {
    "plot_number": 726,
    "property_type": "Residential"
  },
  {
    "plot_number": 727,
    "property_type": "Residential"
  },
  {
    "plot_number": 728,
    "property_type": "Residential"
  },
  {
    "plot_number": 729,
    "property_type": "Residential"
  },
  {
    "plot_number": 730,
    "property_type": "Residential"
  },
  {
    "plot_number": 731,
    "property_type": "Residential"
  },
  {
    "plot_number": 732,
    "property_type": "Residential"
  },
  {
    "plot_number": 733,
    "property_type": "Residential"
  },
  {
    "plot_number": 734,
    "property_type": "Residential"
  },
  {
    "plot_number": 735,
    "property_type": "Residential"
  },
  {
    "plot_number": 736,
    "property_type": "Residential"
  },
  {
    "plot_number": 737,
    "property_type": "Residential"
  },
  {
    "plot_number": 738,
    "property_type": "Residential"
  },
  {
    "plot_number": 739,
    "property_type": "Residential"
  },
  {
    "plot_number": 740,
    "property_type": "Residential"
  },
  {
    "plot_number": 741,
    "property_type": "Residential"
  },
  {
    "plot_number": 742,
    "property_type": "Residential"
  },
  {
    "plot_number": 743,
    "property_type": "Residential"
  },
  {
    "plot_number": 744,
    "property_type": "Residential"
  },
  {
    "plot_number": 745,
    "property_type": "Residential"
  },
  {
    "plot_number": 746,
    "property_type": "Residential"
  },
  {
    "plot_number": 747,
    "property_type": "Residential"
  },
  {
    "plot_number": 748,
    "property_type": "Residential"
  },
  {
    "plot_number": 749,
    "property_type": "Residential"
  },
  {
    "plot_number": 750,
    "property_type": "Residential"
  },
  {
    "plot_number": 751,
    "property_type": "Residential"
  },
  {
    "plot_number": 752,
    "property_type": "Residential"
  },
  {
    "plot_number": 753,
    "property_type": "Residential"
  },
  {
    "plot_number": 754,
    "property_type": "Residential"
  },
  {
    "plot_number": 755,
    "property_type": "Residential"
  },
  {
    "plot_number": 756,
    "property_type": "Residential"
  },
  {
    "plot_number": 757,
    "property_type": "Residential"
  },
  {
    "plot_number": 758,
    "property_type": "Residential"
  },
  {
    "plot_number": 759,
    "property_type": "Residential"
  },
  {
    "plot_number": 760,
    "property_type": "Residential"
  },
  {
    "plot_number": 761,
    "property_type": "Residential"
  },
  {
    "plot_number": 762,
    "property_type": "Residential"
  },
  {
    "plot_number": 763,
    "property_type": "Residential"
  },
  {
    "plot_number": 764,
    "property_type": "Residential"
  },
  {
    "plot_number": 765,
    "property_type": "Residential"
  },
  {
    "plot_number": 766,
    "property_type": "Residential"
  },
  {
    "plot_number": 767,
    "property_type": "Residential"
  },
  {
    "plot_number": 768,
    "property_type": "Residential"
  },
  {
    "plot_number": 769,
    "property_type": "Residential"
  },
  {
    "plot_number": 770,
    "property_type": "Residential"
  },
  {
    "plot_number": 771,
    "property_type": "Residential"
  },
  {
    "plot_number": 772,
    "property_type": "Residential"
  },
  {
    "plot_number": 773,
    "property_type": "Residential"
  },
  {
    "plot_number": 774,
    "property_type": "Residential"
  },
  {
    "plot_number": 775,
    "property_type": "Residential"
  },
  {
    "plot_number": 776,
    "property_type": "Residential"
  },
  {
    "plot_number": 777,
    "property_type": "Residential"
  },
  {
    "plot_number": 778,
    "property_type": "Residential"
  },
  {
    "plot_number": 779,
    "property_type": "Residential"
  },
  {
    "plot_number": 780,
    "property_type": "Residential"
  },
  {
    "plot_number": 781,
    "property_type": "Residential"
  },
  {
    "plot_number": 782,
    "property_type": "Residential"
  },
  {
    "plot_number": 783,
    "property_type": "Residential"
  },
  {
    "plot_number": 784,
    "property_type": "Residential"
  },
  {
    "plot_number": 785,
    "property_type": "Residential"
  },
  {
    "plot_number": 786,
    "property_type": "Residential"
  },
  {
    "plot_number": 787,
    "property_type": "Residential"
  },
  {
    "plot_number": 788,
    "property_type": "Residential"
  },
  {
    "plot_number": 789,
    "property_type": "Residential"
  },
  {
    "plot_number": 790,
    "property_type": "Residential"
  },
  {
    "plot_number": 791,
    "property_type": "Residential"
  },
  {
    "plot_number": 792,
    "property_type": "Residential"
  },
  {
    "plot_number": 793,
    "property_type": "Residential"
  },
  {
    "plot_number": 794,
    "property_type": "Residential"
  },
  {
    "plot_number": 795,
    "property_type": "Residential"
  },
  {
    "plot_number": 796,
    "property_type": "Residential"
  },
  {
    "plot_number": 797,
    "property_type": "Residential"
  },
  {
    "plot_number": 798,
    "property_type": "Residential"
  },
  {
    "plot_number": 799,
    "property_type": "Residential"
  },
  {
    "plot_number": 800,
    "property_type": "Residential"
  },
  {
    "plot_number": 801,
    "property_type": "Residential"
  },
  {
    "plot_number": 802,
    "property_type": "Residential"
  },
  {
    "plot_number": 803,
    "property_type": "Residential"
  },
  {
    "plot_number": 804,
    "property_type": "Residential"
  },
  {
    "plot_number": 805,
    "property_type": "Residential"
  },
  {
    "plot_number": 806,
    "property_type": "Residential"
  },
  {
    "plot_number": 807,
    "property_type": "Residential"
  },
  {
    "plot_number": 808,
    "property_type": "Residential"
  },
  {
    "plot_number": 809,
    "property_type": "Residential"
  },
  {
    "plot_number": 810,
    "property_type": "Residential"
  },
  {
    "plot_number": 811,
    "property_type": "Residential"
  },
  {
    "plot_number": 812,
    "property_type": "Residential"
  },
  {
    "plot_number": 813,
    "property_type": "Residential"
  },
  {
    "plot_number": 814,
    "property_type": "Residential"
  },
  {
    "plot_number": 815,
    "property_type": "Residential"
  },
  {
    "plot_number": 816,
    "property_type": "Residential"
  },
  {
    "plot_number": 817,
    "property_type": "Residential"
  },
  {
    "plot_number": 818,
    "property_type": "Residential"
  },
  {
    "plot_number": 819,
    "property_type": "Residential"
  },
  {
    "plot_number": 820,
    "property_type": "Residential"
  },
  {
    "plot_number": 821,
    "property_type": "Residential"
  },
  {
    "plot_number": 822,
    "property_type": "Residential"
  },
  {
    "plot_number": 823,
    "property_type": "Residential"
  },
  {
    "plot_number": 824,
    "property_type": "Residential"
  },
  {
    "plot_number": 825,
    "property_type": "Residential"
  },
  {
    "plot_number": 826,
    "property_type": "Residential"
  },
  {
    "plot_number": 827,
    "property_type": "Residential"
  },
  {
    "plot_number": 828,
    "property_type": "Residential"
  },
  {
    "plot_number": 829,
    "property_type": "Residential"
  },
  {
    "plot_number": 830,
    "property_type": "Residential"
  },
  {
    "plot_number": 831,
    "property_type": "Residential"
  },
  {
    "plot_number": 832,
    "property_type": "Palacess"
  },
  {
    "plot_number": 833,
    "property_type": "Palacess"
  },
  {
    "plot_number": 834,
    "property_type": "Palacess"
  },
  {
    "plot_number": 835,
    "property_type": "Palacess"
  },
  {
    "plot_number": 836,
    "property_type": "Palacess"
  },
  {
    "plot_number": 837,
    "property_type": "Palacess"
  },
  {
    "plot_number": 838,
    "property_type": "Palacess"
  },
  {
    "plot_number": 839,
    "property_type": "Palacess"
  },
  {
    "plot_number": 840,
    "property_type": "Palacess"
  },
  {
    "plot_number": 841,
    "property_type": "Palacess"
  },
  {
    "plot_number": 842,
    "property_type": "Palacess"
  },
  {
    "plot_number": 843,
    "property_type": "Palacess"
  },
  {
    "plot_number": 844,
    "property_type": "Palacess"
  },
  {
    "plot_number": 845,
    "property_type": "Palacess"
  },
  {
    "plot_number": 846,
    "property_type": "Palacess"
  },
  {
    "plot_number": 847,
    "property_type": "Palacess"
  },
  {
    "plot_number": 848,
    "property_type": "Palacess"
  },
  {
    "plot_number": 883,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 884,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 885,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 886,
    "property_type": "Commercial Residential"
  },
  {
    "plot_number": 887,
    "property_type": "Residential"
  },
  {
    "plot_number": 888,
    "property_type": "Residential"
  },
  {
    "plot_number": 889,
    "property_type": "Residential"
  },
  {
    "plot_number": 890,
    "property_type": "Residential"
  },
  {
    "plot_number": 592,
    "property_type": "Residential"
  },
  {
    "plot_number": 593,
    "property_type": "Residential"
  },
  {
    "plot_number": 594,
    "property_type": "Residential"
  },
  {
    "plot_number": 595,
    "property_type": "Residential"
  },
  {
    "plot_number": 596,
    "property_type": "Residential"
  },
  {
    "plot_number": 597,
    "property_type": "Residential"
  },
  {
    "plot_number": 598,
    "property_type": "Residential"
  },
  {
    "plot_number": 599,
    "property_type": "Residential"
  },
  {
    "plot_number": 600,
    "property_type": "Residential"
  },
  {
    "plot_number": 601,
    "property_type": "Residential"
  },
  {
    "plot_number": 602,
    "property_type": "Residential"
  },
  {
    "plot_number": 603,
    "property_type": "Residential"
  },
  {
    "plot_number": 604,
    "property_type": "Residential"
  },
  {
    "plot_number": 605,
    "property_type": "Residential"
  },
  {
    "plot_number": 606,
    "property_type": "Residential"
  },
  {
    "plot_number": 607,
    "property_type": "Residential"
  },
  {
    "plot_number": 608,
    "property_type": "Residential"
  },
  {
    "plot_number": 609,
    "property_type": "Residential"
  },
  {
    "plot_number": 610,
    "property_type": "Residential"
  },
  {
    "plot_number": 611,
    "property_type": "Residential"
  },
  {
    "plot_number": 612,
    "property_type": "Residential"
  },
  {
    "plot_number": 613,
    "property_type": "Residential"
  },
  {
    "plot_number": 614,
    "property_type": "Residential"
  },
  {
    "plot_number": 615,
    "property_type": "Residential"
  },
  {
    "plot_number": 616,
    "property_type": "Residential"
  },
  {
    "plot_number": 617,
    "property_type": "Residential"
  },
  {
    "plot_number": 618,
    "property_type": "Residential"
  },
  {
    "plot_number": 619,
    "property_type": "Residential"
  },
  {
    "plot_number": 620,
    "property_type": "Residential"
  },
  {
    "plot_number": 621,
    "property_type": "Residential"
  },
  {
    "plot_number": 622,
    "property_type": "Residential"
  },
  {
    "plot_number": 623,
    "property_type": "Residential"
  },
  {
    "plot_number": 624,
    "property_type": "Residential"
  },
  {
    "plot_number": 625,
    "property_type": "Residential"
  },
  {
    "plot_number": 626,
    "property_type": "Residential"
  },
  {
    "plot_number": 627,
    "property_type": "Residential"
  },
  {
    "plot_number": 628,
    "property_type": "Residential"
  },
  {
    "plot_number": 629,
    "property_type": "Residential"
  },
  {
    "plot_number": 630,
    "property_type": "Residential"
  },
  {
    "plot_number": 631,
    "property_type": "Residential"
  },
  {
    "plot_number": 632,
    "property_type": "Residential"
  },
  {
    "plot_number": 633,
    "property_type": "Residential"
  },
  {
    "plot_number": 634,
    "property_type": "Residential"
  },
  {
    "plot_number": 635,
    "property_type": "Residential"
  },
  {
    "plot_number": 636,
    "property_type": "Residential"
  },
  {
    "plot_number": 637,
    "property_type": "Residential"
  },
  {
    "plot_number": 638,
    "property_type": "Residential"
  },
  {
    "plot_number": 639,
    "property_type": "Residential"
  },
  {
    "plot_number": 640,
    "property_type": "Residential"
  },
  {
    "plot_number": 641,
    "property_type": "Residential"
  },
  {
    "plot_number": 642,
    "property_type": "Residential"
  },
  {
    "plot_number": 643,
    "property_type": "Residential"
  },
  {
    "plot_number": 644,
    "property_type": "Residential"
  },
  {
    "plot_number": 645,
    "property_type": "Residential"
  },
  {
    "plot_number": 646,
    "property_type": "Residential"
  },
  {
    "plot_number": 647,
    "property_type": "Residential"
  },
  {
    "plot_number": 648,
    "property_type": "Residential"
  },
  {
    "plot_number": 649,
    "property_type": "Residential"
  },
  {
    "plot_number": 650,
    "property_type": "Residential"
  },
  {
    "plot_number": 651,
    "property_type": "Residential"
  },
  {
    "plot_number": 652,
    "property_type": "Residential"
  },
  {
    "plot_number": 653,
    "property_type": "Residential"
  },
  {
    "plot_number": 654,
    "property_type": "Residential"
  },
  {
    "plot_number": 655,
    "property_type": "Residential"
  },
  {
    "plot_number": 656,
    "property_type": "Residential"
  },
  {
    "plot_number": 657,
    "property_type": "Residential"
  },
  {
    "plot_number": 658,
    "property_type": "Residential"
  },
  {
    "plot_number": 659,
    "property_type": "Residential"
  },
  {
    "plot_number": 660,
    "property_type": "Residential"
  },
  {
    "plot_number": 661,
    "property_type": "Residential"
  },
  {
    "plot_number": 662,
    "property_type": "Residential"
  },
  {
    "plot_number": 663,
    "property_type": "Residential"
  },
  {
    "plot_number": 664,
    "property_type": "Residential"
  },
  {
    "plot_number": 665,
    "property_type": "Residential"
  },
  {
    "plot_number": 666,
    "property_type": "Residential"
  },
  {
    "plot_number": 667,
    "property_type": "Residential"
  },
  {
    "plot_number": 668,
    "property_type": "Residential"
  },
  {
    "plot_number": 669,
    "property_type": "Residential"
  },
  {
    "plot_number": 670,
    "property_type": "Residential"
  },
  {
    "plot_number": 671,
    "property_type": "Residential"
  },
  {
    "plot_number": 672,
    "property_type": "Residential"
  },
  {
    "plot_number": 673,
    "property_type": "Residential"
  },
  {
    "plot_number": 674,
    "property_type": "Residential"
  },
  {
    "plot_number": 675,
    "property_type": "Residential"
  },
  {
    "plot_number": 676,
    "property_type": "Residential"
  },
  {
    "plot_number": 677,
    "property_type": "Residential"
  },
  {
    "plot_number": 678,
    "property_type": "Residential"
  },
  {
    "plot_number": 679,
    "property_type": "Residential"
  },
  {
    "plot_number": 680,
    "property_type": "Residential"
  },
  {
    "plot_number": 681,
    "property_type": "Residential"
  },
  {
    "plot_number": 682,
    "property_type": "Residential"
  },
  {
    "plot_number": 683,
    "property_type": "Residential"
  },
  {
    "plot_number": 684,
    "property_type": "Residential"
  },
  {
    "plot_number": 685,
    "property_type": "Residential"
  },
  {
    "plot_number": 686,
    "property_type": "Palacess"
  },
  {
    "plot_number": 687,
    "property_type": "Palacess"
  },
  {
    "plot_number": 688,
    "property_type": "Palacess"
  },
  {
    "plot_number": 689,
    "property_type": "Palacess"
  },
  {
    "plot_number": 690,
    "property_type": "Palacess"
  },
  {
    "plot_number": 691,
    "property_type": "Palacess"
  },
  {
    "plot_number": 692,
    "property_type": "Palacess"
  },
  {
    "plot_number": 693,
    "property_type": "Palacess"
  },
  {
    "plot_number": 694,
    "property_type": "Palacess"
  },
  {
    "plot_number": 695,
    "property_type": "Palacess"
  },
  {
    "plot_number": 696,
    "property_type": "Palacess"
  },
  {
    "plot_number": 697,
    "property_type": "Palacess"
  },
  {
    "plot_number": 698,
    "property_type": "Palacess"
  },
  {
    "plot_number": 436,
    "property_type": "Palacess"
  },
  {
    "plot_number": 437,
    "property_type": "Palacess"
  },
  {
    "plot_number": 438,
    "property_type": "Palacess"
  },
  {
    "plot_number": 439,
    "property_type": "Palacess"
  },
  {
    "plot_number": 440,
    "property_type": "Palacess"
  },
  {
    "plot_number": 441,
    "property_type": "Palacess"
  },
  {
    "plot_number": 442,
    "property_type": "Palacess"
  },
  {
    "plot_number": 443,
    "property_type": "Palacess"
  },
  {
    "plot_number": 444,
    "property_type": "Palacess"
  },
  {
    "plot_number": 445,
    "property_type": "Palacess"
  },
  {
    "plot_number": 446,
    "property_type": "Palacess"
  },
  {
    "plot_number": 447,
    "property_type": "Palacess"
  },
  {
    "plot_number": 448,
    "property_type": "Palacess"
  },
  {
    "plot_number": 449,
    "property_type": "Palacess"
  },
  {
    "plot_number": 450,
    "property_type": "Palacess"
  },
  {
    "plot_number": 483,
    "property_type": "Residential"
  },
  {
    "plot_number": 484,
    "property_type": "Residential"
  },
  {
    "plot_number": 485,
    "property_type": "Residential"
  },
  {
    "plot_number": 486,
    "property_type": "Residential"
  },
  {
    "plot_number": 487,
    "property_type": "Residential"
  },
  {
    "plot_number": 488,
    "property_type": "Residential"
  },
  {
    "plot_number": 489,
    "property_type": "Residential"
  },
  {
    "plot_number": 490,
    "property_type": "Residential"
  },
  {
    "plot_number": 491,
    "property_type": "Residential"
  },
  {
    "plot_number": 492,
    "property_type": "Residential"
  },
  {
    "plot_number": 493,
    "property_type": "Residential"
  },
  {
    "plot_number": 494,
    "property_type": "Residential"
  },
  {
    "plot_number": 495,
    "property_type": "Residential"
  },
  {
    "plot_number": 496,
    "property_type": "Residential"
  },
  {
    "plot_number": 497,
    "property_type": "Residential"
  },
  {
    "plot_number": 498,
    "property_type": "Residential"
  },
  {
    "plot_number": 499,
    "property_type": "Residential"
  },
  {
    "plot_number": 500,
    "property_type": "Residential"
  },
  {
    "plot_number": 501,
    "property_type": "Residential"
  },
  {
    "plot_number": 502,
    "property_type": "Residential"
  },
  {
    "plot_number": 503,
    "property_type": "Residential"
  },
  {
    "plot_number": 504,
    "property_type": "Residential"
  },
  {
    "plot_number": 505,
    "property_type": "Residential"
  },
  {
    "plot_number": 506,
    "property_type": "Residential"
  },
  {
    "plot_number": 507,
    "property_type": "Residential"
  },
  {
    "plot_number": 508,
    "property_type": "Residential"
  },
  {
    "plot_number": 509,
    "property_type": "Residential"
  },
  {
    "plot_number": 510,
    "property_type": "Residential"
  },
  {
    "plot_number": 511,
    "property_type": "Residential"
  },
  {
    "plot_number": 512,
    "property_type": "Residential"
  },
  {
    "plot_number": 513,
    "property_type": "Residential"
  },
  {
    "plot_number": 514,
    "property_type": "Residential"
  },
  {
    "plot_number": 515,
    "property_type": "Residential"
  },
  {
    "plot_number": 516,
    "property_type": "Residential"
  },
  {
    "plot_number": 517,
    "property_type": "Residential"
  },
  {
    "plot_number": 519,
    "property_type": "Residential"
  },
  {
    "plot_number": 521,
    "property_type": "Residential"
  },
  {
    "plot_number": 523,
    "property_type": "Residential"
  },
  {
    "plot_number": 525,
    "property_type": "Residential"
  },
  {
    "plot_number": 526,
    "property_type": "Residential"
  },
  {
    "plot_number": 527,
    "property_type": "Residential"
  },
  {
    "plot_number": 528,
    "property_type": "Residential"
  },
  {
    "plot_number": 529,
    "property_type": "Residential"
  },
  {
    "plot_number": 530,
    "property_type": "Residential"
  },
  {
    "plot_number": 531,
    "property_type": "Residential"
  },
  {
    "plot_number": 532,
    "property_type": "Residential"
  },
  {
    "plot_number": 533,
    "property_type": "Residential"
  },
  {
    "plot_number": 534,
    "property_type": "Residential"
  },
  {
    "plot_number": 535,
    "property_type": "Residential"
  },
  {
    "plot_number": 536,
    "property_type": "Residential"
  },
  {
    "plot_number": 537,
    "property_type": "Residential"
  },
  {
    "plot_number": 538,
    "property_type": "Residential"
  },
  {
    "plot_number": 539,
    "property_type": "Residential"
  },
  {
    "plot_number": 540,
    "property_type": "Residential"
  },
  {
    "plot_number": 541,
    "property_type": "Residential"
  },
  {
    "plot_number": 542,
    "property_type": "Residential"
  },
  {
    "plot_number": 543,
    "property_type": "Residential"
  },
  {
    "plot_number": 544,
    "property_type": "Residential"
  },
  {
    "plot_number": 545,
    "property_type": "Residential"
  },
  {
    "plot_number": 562,
    "property_type": "Residential"
  },
  {
    "plot_number": 563,
    "property_type": "Residential"
  },
  {
    "plot_number": 564,
    "property_type": "Residential"
  },
  {
    "plot_number": 565,
    "property_type": "Residential"
  },
  {
    "plot_number": 566,
    "property_type": "Residential"
  },
  {
    "plot_number": 567,
    "property_type": "Residential"
  },
  {
    "plot_number": 568,
    "property_type": "Residential"
  },
  {
    "plot_number": 569,
    "property_type": "Residential"
  },
  {
    "plot_number": 570,
    "property_type": "Residential"
  },
  {
    "plot_number": 571,
    "property_type": "Residential"
  },
  {
    "plot_number": 572,
    "property_type": "Residential"
  },
  {
    "plot_number": 573,
    "property_type": "Residential"
  },
  {
    "plot_number": 574,
    "property_type": "Residential"
  },
  {
    "plot_number": 575,
    "property_type": "Residential"
  },
  {
    "plot_number": 576,
    "property_type": "Residential"
  },
  {
    "plot_number": 577,
    "property_type": "Residential"
  },
  {
    "plot_number": 578,
    "property_type": "Residential"
  },
  {
    "plot_number": 579,
    "property_type": "Residential"
  },
  {
    "plot_number": 580,
    "property_type": "Residential"
  },
  {
    "plot_number": 581,
    "property_type": "Residential"
  },
  {
    "plot_number": 582,
    "property_type": "Residential"
  },
  {
    "plot_number": 583,
    "property_type": "Residential"
  },
  {
    "plot_number": 584,
    "property_type": "Residential"
  },
  {
    "plot_number": 585,
    "property_type": "Residential"
  },
  {
    "plot_number": 586,
    "property_type": "Residential"
  },
  {
    "plot_number": 587,
    "property_type": "Residential"
  },
  {
    "plot_number": 588,
    "property_type": "Residential"
  },
  {
    "plot_number": 589,
    "property_type": "Residential"
  },
  {
    "plot_number": 590,
    "property_type": "Residential"
  },
  {
    "plot_number": 591,
    "property_type": "Residential"
  },
  {
    "plot_number": 893,
    "property_type": "Residential"
  },
  {
    "plot_number": 894,
    "property_type": "Residential"
  },
  {
    "plot_number": 895,
    "property_type": "Residential"
  },
  {
    "plot_number": 896,
    "property_type": "Residential"
  },
  {
    "plot_number": 909,
    "property_type": "commercial"
  },
  {
    "plot_number": 1,
    "property_type": "Towers"
  },
  {
    "plot_number": 2,
    "property_type": "Towers"
  },
  {
    "plot_number": 3,
    "property_type": "Towers"
  },
  {
    "plot_number": 4,
    "property_type": "Towers"
  },
  {
    "plot_number": 5,
    "property_type": "Towers"
  },
  {
    "plot_number": 6,
    "property_type": "Towers"
  },
  {
    "plot_number": 7,
    "property_type": "Towers"
  },
  {
    "plot_number": 8,
    "property_type": "Towers"
  },
  {
    "plot_number": 9,
    "property_type": "Towers"
  },
  {
    "plot_number": 10,
    "property_type": "Towers"
  },
  {
    "plot_number": 11,
    "property_type": "Towers"
  },
  {
    "plot_number": 12,
    "property_type": "Towers"
  },
  {
    "plot_number": 13,
    "property_type": "Towers"
  },
  {
    "plot_number": 14,
    "property_type": "Towers"
  },
  {
    "plot_number": 15,
    "property_type": "Towers"
  },
  {
    "plot_number": 16,
    "property_type": "Towers"
  },
  {
    "plot_number": 17,
    "property_type": "Towers"
  },
  {
    "plot_number": 18,
    "property_type": "Towers"
  },
  {
    "plot_number": 19,
    "property_type": "Towers"
  },
  {
    "plot_number": 20,
    "property_type": "Towers"
  },
  {
    "plot_number": 21,
    "property_type": "Towers"
  },
  {
    "plot_number": 22,
    "property_type": "Towers"
  },
  {
    "plot_number": 23,
    "property_type": "Towers"
  },
  {
    "plot_number": 24,
    "property_type": "Towers"
  },
  {
    "plot_number": 25,
    "property_type": "Towers"
  },
  {
    "plot_number": 26,
    "property_type": "Towers"
  },
  {
    "plot_number": 27,
    "property_type": "Towers"
  },
  {
    "plot_number": 28,
    "property_type": "Towers"
  },
  {
    "plot_number": 29,
    "property_type": "Towers"
  },
  {
    "plot_number": 30,
    "property_type": "Towers"
  },
  {
    "plot_number": 31,
    "property_type": "Towers"
  },
  {
    "plot_number": 32,
    "property_type": "Towers"
  },
  {
    "plot_number": 33,
    "property_type": "Towers"
  },
  {
    "plot_number": 34,
    "property_type": "Towers"
  },
  {
    "plot_number": 35,
    "property_type": "Towers"
  },
  {
    "plot_number": 36,
    "property_type": "Towers"
  },
  {
    "plot_number": 37,
    "property_type": "Towers"
  },
  {
    "plot_number": 38,
    "property_type": "Towers"
  },
  {
    "plot_number": 39,
    "property_type": "Towers"
  },
  {
    "plot_number": 40,
    "property_type": "Towers"
  },
  {
    "plot_number": 41,
    "property_type": "Towers"
  },
  {
    "plot_number": 42,
    "property_type": "Towers"
  },
  {
    "plot_number": 43,
    "property_type": "Towers"
  },
  {
    "plot_number": 44,
    "property_type": "Towers"
  },
  {
    "plot_number": 45,
    "property_type": "Towers"
  },
  {
    "plot_number": 46,
    "property_type": "Towers"
  },
  {
    "plot_number": 47,
    "property_type": "Towers"
  },
  {
    "plot_number": 48,
    "property_type": "Towers"
  },
  {
    "plot_number": 49,
    "property_type": "Towers"
  },
  {
    "plot_number": 50,
    "property_type": "Towers"
  },
  {
    "plot_number": 51,
    "property_type": "Towers"
  },
  {
    "plot_number": 52,
    "property_type": "Towers"
  },
  {
    "plot_number": 53,
    "property_type": "Towers"
  },
  {
    "plot_number": 54,
    "property_type": "Towers"
  },
  {
    "plot_number": 55,
    "property_type": "Towers"
  },
  {
    "plot_number": 56,
    "property_type": "Towers"
  },
  {
    "plot_number": 57,
    "property_type": "Towers"
  },
  {
    "plot_number": 58,
    "property_type": "Towers"
  },
  {
    "plot_number": 59,
    "property_type": "Towers"
  },
  {
    "plot_number": 60,
    "property_type": "Towers"
  },
  {
    "plot_number": 61,
    "property_type": "Towers"
  },
  {
    "plot_number": 62,
    "property_type": "Towers"
  },
  {
    "plot_number": 63,
    "property_type": "Towers"
  },
  {
    "plot_number": 64,
    "property_type": "Towers"
  },
  {
    "plot_number": 65,
    "property_type": "Towers"
  },
  {
    "plot_number": 66,
    "property_type": "Towers"
  },
  {
    "plot_number": 67,
    "property_type": "Towers"
  },
  {
    "plot_number": 68,
    "property_type": "Towers"
  },
  {
    "plot_number": 69,
    "property_type": "Towers"
  },
  {
    "plot_number": 70,
    "property_type": "Towers"
  },
  {
    "plot_number": 71,
    "property_type": "Towers"
  },
  {
    "plot_number": 72,
    "property_type": "Towers"
  },
  {
    "plot_number": 73,
    "property_type": "Towers"
  },
  {
    "plot_number": 74,
    "property_type": "Palacess"
  },
  {
    "plot_number": 75,
    "property_type": "Palacess"
  },
  {
    "plot_number": 76,
    "property_type": "Palacess"
  },
  {
    "plot_number": 77,
    "property_type": "Palacess"
  },
  {
    "plot_number": 78,
    "property_type": "Palacess"
  },
  {
    "plot_number": 79,
    "property_type": "Palacess"
  },
  {
    "plot_number": 80,
    "property_type": "Palacess"
  },
  {
    "plot_number": 81,
    "property_type": "Palacess"
  },
  {
    "plot_number": 82,
    "property_type": "Palacess"
  },
  {
    "plot_number": 83,
    "property_type": "Palacess"
  },
  {
    "plot_number": 84,
    "property_type": "Palacess"
  },
  {
    "plot_number": 85,
    "property_type": "Palacess"
  },
  {
    "plot_number": 86,
    "property_type": "Palacess"
  },
  {
    "plot_number": 87,
    "property_type": "Palacess"
  },
  {
    "plot_number": 88,
    "property_type": "Palacess"
  },
  {
    "plot_number": 89,
    "property_type": "Palacess"
  },
  {
    "plot_number": 90,
    "property_type": "Palacess"
  },
  {
    "plot_number": 91,
    "property_type": "Residential"
  },
  {
    "plot_number": 92,
    "property_type": "Residential"
  },
  {
    "plot_number": 93,
    "property_type": "Residential"
  },
  {
    "plot_number": 94,
    "property_type": "Residential"
  },
  {
    "plot_number": 95,
    "property_type": "Residential"
  },
  {
    "plot_number": 96,
    "property_type": "Residential"
  },
  {
    "plot_number": 97,
    "property_type": "Residential"
  },
  {
    "plot_number": 98,
    "property_type": "Residential"
  },
  {
    "plot_number": 99,
    "property_type": "Residential"
  },
  {
    "plot_number": 100,
    "property_type": "Residential"
  },
  {
    "plot_number": 101,
    "property_type": "Residential"
  },
  {
    "plot_number": 102,
    "property_type": "Residential"
  },
  {
    "plot_number": 103,
    "property_type": "Residential"
  },
  {
    "plot_number": 104,
    "property_type": "Residential"
  },
  {
    "plot_number": 105,
    "property_type": "Residential"
  },
  {
    "plot_number": 106,
    "property_type": "Residential"
  },
  {
    "plot_number": 107,
    "property_type": "Residential"
  },
  {
    "plot_number": 108,
    "property_type": "Residential"
  },
  {
    "plot_number": 109,
    "property_type": "Residential"
  },
  {
    "plot_number": 110,
    "property_type": "Residential"
  },
  {
    "plot_number": 111,
    "property_type": "Residential"
  },
  {
    "plot_number": 112,
    "property_type": "Residential"
  },
  {
    "plot_number": 113,
    "property_type": "Residential"
  },
  {
    "plot_number": 114,
    "property_type": "Residential"
  },
  {
    "plot_number": 115,
    "property_type": "Residential"
  },
  {
    "plot_number": 116,
    "property_type": "Residential"
  },
  {
    "plot_number": 117,
    "property_type": "Residential"
  },
  {
    "plot_number": 118,
    "property_type": "Residential"
  },
  {
    "plot_number": 119,
    "property_type": "Residential"
  },
  {
    "plot_number": 120,
    "property_type": "Residential"
  },
  {
    "plot_number": 121,
    "property_type": "Residential"
  },
  {
    "plot_number": 122,
    "property_type": "Residential"
  },
  {
    "plot_number": 123,
    "property_type": "Residential"
  },
  {
    "plot_number": 124,
    "property_type": "Residential"
  },
  {
    "plot_number": 125,
    "property_type": "Residential"
  },
  {
    "plot_number": 126,
    "property_type": "Residential"
  },
  {
    "plot_number": 127,
    "property_type": "Residential"
  },
  {
    "plot_number": 128,
    "property_type": "Residential"
  },
  {
    "plot_number": 129,
    "property_type": "Residential"
  },
  {
    "plot_number": 130,
    "property_type": "Residential"
  },
  {
    "plot_number": 131,
    "property_type": "Residential"
  },
  {
    "plot_number": 132,
    "property_type": "Residential"
  },
  {
    "plot_number": 133,
    "property_type": "Residential"
  },
  {
    "plot_number": 134,
    "property_type": "Residential"
  },
  {
    "plot_number": 135,
    "property_type": "Residential"
  },
  {
    "plot_number": 136,
    "property_type": "Residential"
  },
  {
    "plot_number": 137,
    "property_type": "Residential"
  },
  {
    "plot_number": 138,
    "property_type": "Residential"
  },
  {
    "plot_number": 139,
    "property_type": "Residential"
  },
  {
    "plot_number": 140,
    "property_type": "Residential"
  },
  {
    "plot_number": 141,
    "property_type": "Residential"
  },
  {
    "plot_number": 142,
    "property_type": "Residential"
  },
  {
    "plot_number": 143,
    "property_type": "Residential"
  },
  {
    "plot_number": 144,
    "property_type": "Residential"
  },
  {
    "plot_number": 145,
    "property_type": "Residential"
  },
  {
    "plot_number": 146,
    "property_type": "Residential"
  },
  {
    "plot_number": 147,
    "property_type": "Residential"
  },
  {
    "plot_number": 148,
    "property_type": "Residential"
  },
  {
    "plot_number": 149,
    "property_type": "Residential"
  },
  {
    "plot_number": 150,
    "property_type": "Residential"
  },
  {
    "plot_number": 151,
    "property_type": "Residential"
  },
  {
    "plot_number": 152,
    "property_type": "Residential"
  },
  {
    "plot_number": 153,
    "property_type": "Residential"
  },
  {
    "plot_number": 154,
    "property_type": "Residential"
  },
  {
    "plot_number": 155,
    "property_type": "Residential"
  },
  {
    "plot_number": 156,
    "property_type": "Residential"
  },
  {
    "plot_number": 157,
    "property_type": "Residential"
  },
  {
    "plot_number": 158,
    "property_type": "Residential"
  },
  {
    "plot_number": 159,
    "property_type": "Residential"
  },
  {
    "plot_number": 160,
    "property_type": "Residential"
  },
  {
    "plot_number": 161,
    "property_type": "Residential"
  },
  {
    "plot_number": 162,
    "property_type": "Residential"
  },
  {
    "plot_number": 163,
    "property_type": "Residential"
  },
  {
    "plot_number": 164,
    "property_type": "Residential"
  },
  {
    "plot_number": 165,
    "property_type": "Residential"
  },
  {
    "plot_number": 166,
    "property_type": "Residential"
  },
  {
    "plot_number": 167,
    "property_type": "Residential"
  },
  {
    "plot_number": 168,
    "property_type": "Residential"
  },
  {
    "plot_number": 169,
    "property_type": "Residential"
  },
  {
    "plot_number": 170,
    "property_type": "Residential"
  },
  {
    "plot_number": 171,
    "property_type": "Residential"
  },
  {
    "plot_number": 172,
    "property_type": "Residential"
  },
  {
    "plot_number": 173,
    "property_type": "Residential"
  },
  {
    "plot_number": 174,
    "property_type": "Residential"
  },
  {
    "plot_number": 175,
    "property_type": "Residential"
  },
  {
    "plot_number": 176,
    "property_type": "Residential"
  },
  {
    "plot_number": 177,
    "property_type": "Residential"
  },
  {
    "plot_number": 178,
    "property_type": "Residential"
  },
  {
    "plot_number": 179,
    "property_type": "Residential"
  },
  {
    "plot_number": 180,
    "property_type": "Residential"
  },
  {
    "plot_number": 181,
    "property_type": "Residential"
  },
  {
    "plot_number": 182,
    "property_type": "Residential"
  },
  {
    "plot_number": 183,
    "property_type": "Residential"
  },
  {
    "plot_number": 184,
    "property_type": "Residential"
  },
  {
    "plot_number": 185,
    "property_type": "Residential"
  },
  {
    "plot_number": 186,
    "property_type": "Residential"
  },
  {
    "plot_number": 187,
    "property_type": "Residential"
  },
  {
    "plot_number": 188,
    "property_type": "Residential"
  },
  {
    "plot_number": 189,
    "property_type": "Residential"
  },
  {
    "plot_number": 190,
    "property_type": "Residential"
  },
  {
    "plot_number": 191,
    "property_type": "Residential"
  },
  {
    "plot_number": 192,
    "property_type": "Residential"
  },
  {
    "plot_number": 193,
    "property_type": "Residential"
  },
  {
    "plot_number": 194,
    "property_type": "Residential"
  },
  {
    "plot_number": 195,
    "property_type": "Residential"
  },
  {
    "plot_number": 196,
    "property_type": "Residential"
  },
  {
    "plot_number": 197,
    "property_type": "Residential"
  },
  {
    "plot_number": 198,
    "property_type": "Residential"
  },
  {
    "plot_number": 199,
    "property_type": "Residential"
  },
  {
    "plot_number": 200,
    "property_type": "Residential"
  },
  {
    "plot_number": 201,
    "property_type": "Residential"
  },
  {
    "plot_number": 202,
    "property_type": "Residential"
  },
  {
    "plot_number": 203,
    "property_type": "Residential"
  },
  {
    "plot_number": 204,
    "property_type": "Residential"
  },
  {
    "plot_number": 205,
    "property_type": "Residential"
  },
  {
    "plot_number": 206,
    "property_type": "Residential"
  },
  {
    "plot_number": 207,
    "property_type": "Residential"
  },
  {
    "plot_number": 208,
    "property_type": "Residential"
  },
  {
    "plot_number": 209,
    "property_type": "Residential"
  },
  {
    "plot_number": 210,
    "property_type": "Residential"
  },
  {
    "plot_number": 211,
    "property_type": "Residential"
  },
  {
    "plot_number": 212,
    "property_type": "Residential"
  },
  {
    "plot_number": 213,
    "property_type": "Residential"
  },
  {
    "plot_number": 214,
    "property_type": "Residential"
  },
  {
    "plot_number": 215,
    "property_type": "Residential"
  },
  {
    "plot_number": 216,
    "property_type": "Residential"
  },
  {
    "plot_number": 217,
    "property_type": "Residential"
  },
  {
    "plot_number": 218,
    "property_type": "Residential"
  },
  {
    "plot_number": 219,
    "property_type": "Residential"
  },
  {
    "plot_number": 220,
    "property_type": "Residential"
  },
  {
    "plot_number": 221,
    "property_type": "Residential"
  },
  {
    "plot_number": 222,
    "property_type": "Residential"
  },
  {
    "plot_number": 223,
    "property_type": "Residential"
  },
  {
    "plot_number": 224,
    "property_type": "Residential"
  },
  {
    "plot_number": 225,
    "property_type": "Residential"
  },
  {
    "plot_number": 226,
    "property_type": "Residential"
  },
  {
    "plot_number": 227,
    "property_type": "Residential"
  },
  {
    "plot_number": 228,
    "property_type": "Residential"
  },
  {
    "plot_number": 229,
    "property_type": "Residential"
  },
  {
    "plot_number": 230,
    "property_type": "Residential"
  },
  {
    "plot_number": 231,
    "property_type": "Residential"
  },
  {
    "plot_number": 232,
    "property_type": "Residential"
  },
  {
    "plot_number": 233,
    "property_type": "Residential"
  },
  {
    "plot_number": 234,
    "property_type": "Residential"
  },
  {
    "plot_number": 235,
    "property_type": "Residential"
  },
  {
    "plot_number": 236,
    "property_type": "Residential"
  },
  {
    "plot_number": 237,
    "property_type": "Residential"
  },
  {
    "plot_number": 238,
    "property_type": "Residential"
  },
  {
    "plot_number": 239,
    "property_type": "Residential"
  },
  {
    "plot_number": 240,
    "property_type": "Residential"
  },
  {
    "plot_number": 241,
    "property_type": "Residential"
  },
  {
    "plot_number": 242,
    "property_type": "Residential"
  },
  {
    "plot_number": 243,
    "property_type": "Residential"
  },
  {
    "plot_number": 244,
    "property_type": "Residential"
  },
  {
    "plot_number": 245,
    "property_type": "Residential"
  },
  {
    "plot_number": 246,
    "property_type": "Residential"
  },
  {
    "plot_number": 247,
    "property_type": "Residential"
  },
  {
    "plot_number": 248,
    "property_type": "Residential"
  },
  {
    "plot_number": 249,
    "property_type": "Residential"
  },
  {
    "plot_number": 250,
    "property_type": "Residential"
  },
  {
    "plot_number": 251,
    "property_type": "Residential"
  },
  {
    "plot_number": 252,
    "property_type": "Residential"
  },
  {
    "plot_number": 253,
    "property_type": "Residential"
  },
  {
    "plot_number": 254,
    "property_type": "Palacess"
  },
  {
    "plot_number": 255,
    "property_type": "Palacess"
  },
  {
    "plot_number": 256,
    "property_type": "Palacess"
  },
  {
    "plot_number": 257,
    "property_type": "Palacess"
  },
  {
    "plot_number": 258,
    "property_type": "Palacess"
  },
  {
    "plot_number": 259,
    "property_type": "Palacess"
  },
  {
    "plot_number": 260,
    "property_type": "Palacess"
  },
  {
    "plot_number": 261,
    "property_type": "Palacess"
  },
  {
    "plot_number": 262,
    "property_type": "Palacess"
  },
  {
    "plot_number": 263,
    "property_type": "Palacess"
  },
  {
    "plot_number": 264,
    "property_type": "Palacess"
  },
  {
    "plot_number": 265,
    "property_type": "Palacess"
  },
  {
    "plot_number": 266,
    "property_type": "Residential"
  },
  {
    "plot_number": 267,
    "property_type": "Residential"
  },
  {
    "plot_number": 268,
    "property_type": "Residential"
  },
  {
    "plot_number": 269,
    "property_type": "Residential"
  },
  {
    "plot_number": 270,
    "property_type": "Residential"
  },
  {
    "plot_number": 271,
    "property_type": "Residential"
  },
  {
    "plot_number": 272,
    "property_type": "Residential"
  },
  {
    "plot_number": 273,
    "property_type": "Residential"
  },
  {
    "plot_number": 274,
    "property_type": "Residential"
  },
  {
    "plot_number": 275,
    "property_type": "Residential"
  },
  {
    "plot_number": 276,
    "property_type": "Residential"
  },
  {
    "plot_number": 277,
    "property_type": "Residential"
  },
  {
    "plot_number": 285,
    "property_type": "Palacess"
  },
  {
    "plot_number": 286,
    "property_type": "Palacess"
  },
  {
    "plot_number": 287,
    "property_type": "Palacess"
  },
  {
    "plot_number": 288,
    "property_type": "Palacess"
  },
  {
    "plot_number": 289,
    "property_type": "Palacess"
  },
  {
    "plot_number": 290,
    "property_type": "Palacess"
  },
  {
    "plot_number": 291,
    "property_type": "Palacess"
  },
  {
    "plot_number": 292,
    "property_type": "Palacess"
  },
  {
    "plot_number": 293,
    "property_type": "Residential"
  },
  {
    "plot_number": 294,
    "property_type": "Residential"
  },
  {
    "plot_number": 296,
    "property_type": "Residential"
  },
  {
    "plot_number": 297,
    "property_type": "Residential"
  },
  {
    "plot_number": 299,
    "property_type": "Residential"
  },
  {
    "plot_number": 300,
    "property_type": "Residential"
  },
  {
    "plot_number": 301,
    "property_type": "Residential"
  },
  {
    "plot_number": 302,
    "property_type": "Residential"
  },
  {
    "plot_number": 303,
    "property_type": "Residential"
  },
  {
    "plot_number": 304,
    "property_type": "Residential"
  },
  {
    "plot_number": 305,
    "property_type": "Residential"
  },
  {
    "plot_number": 306,
    "property_type": "Residential"
  },
  {
    "plot_number": 307,
    "property_type": "Residential"
  },
  {
    "plot_number": 308,
    "property_type": "Residential"
  },
  {
    "plot_number": 309,
    "property_type": "Residential"
  },
  {
    "plot_number": 310,
    "property_type": "Residential"
  },
  {
    "plot_number": 311,
    "property_type": "Residential"
  },
  {
    "plot_number": 312,
    "property_type": "Residential"
  },
  {
    "plot_number": 313,
    "property_type": "Residential"
  },
  {
    "plot_number": 314,
    "property_type": "Residential"
  },
  {
    "plot_number": 315,
    "property_type": "Residential"
  },
  {
    "plot_number": 316,
    "property_type": "Residential"
  },
  {
    "plot_number": 317,
    "property_type": "Residential"
  },
  {
    "plot_number": 318,
    "property_type": "Residential"
  },
  {
    "plot_number": 319,
    "property_type": "Residential"
  },
  {
    "plot_number": 320,
    "property_type": "Residential"
  },
  {
    "plot_number": 321,
    "property_type": "Residential"
  },
  {
    "plot_number": 322,
    "property_type": "Residential"
  },
  {
    "plot_number": 323,
    "property_type": "Residential"
  },
  {
    "plot_number": 324,
    "property_type": "Residential"
  },
  {
    "plot_number": 325,
    "property_type": "Residential"
  },
  {
    "plot_number": 326,
    "property_type": "Residential"
  },
  {
    "plot_number": 327,
    "property_type": "Residential"
  },
  {
    "plot_number": 329,
    "property_type": "Residential"
  },
  {
    "plot_number": 330,
    "property_type": "Residential"
  },
  {
    "plot_number": 331,
    "property_type": "Residential"
  },
  {
    "plot_number": 332,
    "property_type": "Residential"
  },
  {
    "plot_number": 333,
    "property_type": "Residential"
  },
  {
    "plot_number": 334,
    "property_type": "Residential"
  },
  {
    "plot_number": 335,
    "property_type": "Residential"
  },
  {
    "plot_number": 336,
    "property_type": "Residential"
  },
  {
    "plot_number": 337,
    "property_type": "Residential"
  },
  {
    "plot_number": 338,
    "property_type": "Residential"
  },
  {
    "plot_number": 339,
    "property_type": "Residential"
  },
  {
    "plot_number": 340,
    "property_type": "Residential"
  },
  {
    "plot_number": 341,
    "property_type": "Residential"
  },
  {
    "plot_number": 342,
    "property_type": "Residential"
  },
  {
    "plot_number": 343,
    "property_type": "Residential"
  },
  {
    "plot_number": 344,
    "property_type": "Residential"
  },
  {
    "plot_number": 345,
    "property_type": "Residential"
  },
  {
    "plot_number": 346,
    "property_type": "Residential"
  },
  {
    "plot_number": 347,
    "property_type": "Residential"
  },
  {
    "plot_number": 348,
    "property_type": "Residential"
  },
  {
    "plot_number": 349,
    "property_type": "Residential"
  },
  {
    "plot_number": 350,
    "property_type": "Residential"
  },
  {
    "plot_number": 351,
    "property_type": "Residential"
  },
  {
    "plot_number": 352,
    "property_type": "Residential"
  },
  {
    "plot_number": 353,
    "property_type": "Residential"
  },
  {
    "plot_number": 354,
    "property_type": "Residential"
  },
  {
    "plot_number": 355,
    "property_type": "Residential"
  },
  {
    "plot_number": 356,
    "property_type": "Residential"
  },
  {
    "plot_number": 357,
    "property_type": "Residential"
  },
  {
    "plot_number": 358,
    "property_type": "Residential"
  },
  {
    "plot_number": 359,
    "property_type": "Residential"
  },
  {
    "plot_number": 360,
    "property_type": "Residential"
  },
  {
    "plot_number": 361,
    "property_type": "Residential"
  },
  {
    "plot_number": 362,
    "property_type": "Residential"
  },
  {
    "plot_number": 363,
    "property_type": "Residential"
  },
  {
    "plot_number": 364,
    "property_type": "Residential"
  },
  {
    "plot_number": 365,
    "property_type": "Residential"
  },
  {
    "plot_number": 366,
    "property_type": "Residential"
  },
  {
    "plot_number": 367,
    "property_type": "Residential"
  },
  {
    "plot_number": 368,
    "property_type": "Residential"
  },
  {
    "plot_number": 369,
    "property_type": "Residential"
  },
  {
    "plot_number": 370,
    "property_type": "Residential"
  },
  {
    "plot_number": 372,
    "property_type": "Residential"
  },
  {
    "plot_number": 373,
    "property_type": "Residential"
  },
  {
    "plot_number": 374,
    "property_type": "Residential"
  },
  {
    "plot_number": 375,
    "property_type": "Residential"
  },
  {
    "plot_number": 376,
    "property_type": "Residential"
  },
  {
    "plot_number": 377,
    "property_type": "Residential"
  },
  {
    "plot_number": 378,
    "property_type": "Residential"
  },
  {
    "plot_number": 379,
    "property_type": "Residential"
  },
  {
    "plot_number": 380,
    "property_type": "Residential"
  },
  {
    "plot_number": 381,
    "property_type": "Residential"
  },
  {
    "plot_number": 382,
    "property_type": "Residential"
  },
  {
    "plot_number": 383,
    "property_type": "Residential"
  },
  {
    "plot_number": 384,
    "property_type": "Residential"
  },
  {
    "plot_number": 385,
    "property_type": "Residential"
  },
  {
    "plot_number": 386,
    "property_type": "Residential"
  },
  {
    "plot_number": 387,
    "property_type": "Residential"
  },
  {
    "plot_number": 388,
    "property_type": "Residential"
  },
  {
    "plot_number": 389,
    "property_type": "Residential"
  },
  {
    "plot_number": 390,
    "property_type": "Residential"
  },
  {
    "plot_number": 391,
    "property_type": "Residential"
  },
  {
    "plot_number": 392,
    "property_type": "Residential"
  },
  {
    "plot_number": 393,
    "property_type": "Residential"
  },
  {
    "plot_number": 394,
    "property_type": "Residential"
  },
  {
    "plot_number": 395,
    "property_type": "Residential"
  },
  {
    "plot_number": 396,
    "property_type": "Residential"
  },
  {
    "plot_number": 397,
    "property_type": "Residential"
  },
  {
    "plot_number": 398,
    "property_type": "Residential"
  },
  {
    "plot_number": 399,
    "property_type": "Residential"
  },
  {
    "plot_number": 400,
    "property_type": "Residential"
  },
  {
    "plot_number": 401,
    "property_type": "Residential"
  },
  {
    "plot_number": 402,
    "property_type": "Residential"
  },
  {
    "plot_number": 403,
    "property_type": "Residential"
  },
  {
    "plot_number": 404,
    "property_type": "Residential"
  },
  {
    "plot_number": 405,
    "property_type": "Residential"
  },
  {
    "plot_number": 406,
    "property_type": "Residential"
  },
  {
    "plot_number": 407,
    "property_type": "Residential"
  },
  {
    "plot_number": 408,
    "property_type": "Residential"
  },
  {
    "plot_number": 409,
    "property_type": "Residential"
  },
  {
    "plot_number": 410,
    "property_type": "Residential"
  },
  {
    "plot_number": 411,
    "property_type": "Residential"
  },
  {
    "plot_number": 412,
    "property_type": "Residential"
  },
  {
    "plot_number": 413,
    "property_type": "Residential"
  },
  {
    "plot_number": 414,
    "property_type": "Residential"
  },
  {
    "plot_number": 415,
    "property_type": "Residential"
  },
  {
    "plot_number": 416,
    "property_type": "Residential"
  },
  {
    "plot_number": 417,
    "property_type": "Palacess"
  },
  {
    "plot_number": 418,
    "property_type": "Palacess"
  },
  {
    "plot_number": 419,
    "property_type": "Palacess"
  },
  {
    "plot_number": 420,
    "property_type": "Palacess"
  },
  {
    "plot_number": 421,
    "property_type": "Palacess"
  },
  {
    "plot_number": 422,
    "property_type": "Palacess"
  },
  {
    "plot_number": 423,
    "property_type": "Palacess"
  },
  {
    "plot_number": 424,
    "property_type": "Palacess"
  },
  {
    "plot_number": 425,
    "property_type": "Palacess"
  },
  {
    "plot_number": 426,
    "property_type": "Palacess"
  },
  {
    "plot_number": 427,
    "property_type": "Palacess"
  },
  {
    "plot_number": 428,
    "property_type": "Palacess"
  },
  {
    "plot_number": 429,
    "property_type": "Palacess"
  },
  {
    "plot_number": 430,
    "property_type": "Palacess"
  },
  {
    "plot_number": 431,
    "property_type": "Palacess"
  },
  {
    "plot_number": 432,
    "property_type": "Palacess"
  },
  {
    "plot_number": 433,
    "property_type": "Palacess"
  },
  {
    "plot_number": 434,
    "property_type": "Palacess"
  },
  {
    "plot_number": 435,
    "property_type": "Palacess"
  },
  {
    "plot_number": "zone 9"
  },
  {
    "plot_number": 849,
    "property_type": "Palacess"
  },
  {
    "plot_number": 850,
    "property_type": "Palacess"
  },
  {
    "plot_number": 851,
    "property_type": "Palacess"
  },
  {
    "plot_number": 852,
    "property_type": "Palacess"
  },
  {
    "plot_number": 853,
    "property_type": "Palacess"
  },
  {
    "plot_number": 854,
    "property_type": "Palacess"
  },
  {
    "plot_number": 855,
    "property_type": "Palacess"
  },
  {
    "plot_number": 856,
    "property_type": "Palacess"
  },
  {
    "plot_number": 857,
    "property_type": "Palacess"
  },
  {
    "plot_number": 858,
    "property_type": "Palacess"
  },
  {
    "plot_number": 859,
    "property_type": "Palacess"
  },
  {
    "plot_number": 860,
    "property_type": "Palacess"
  },
  {
    "plot_number": 861,
    "property_type": "Palacess"
  },
  {
    "plot_number": 862,
    "property_type": "Palacess"
  },
  {
    "plot_number": 863,
    "property_type": "Palacess"
  },
  {
    "plot_number": 864,
    "property_type": "Palacess"
  },
  {
    "plot_number": 865,
    "property_type": "Palacess"
  },
  {
    "plot_number": 866,
    "property_type": "Palacess"
  },
  {
    "plot_number": 867,
    "property_type": "Palacess"
  },
  {
    "plot_number": 868,
    "property_type": "Palacess"
  },
  {
    "plot_number": 869,
    "property_type": "Palacess"
  },
  {
    "plot_number": 870,
    "property_type": "Palacess"
  },
  {
    "plot_number": 871,
    "property_type": "Palacess"
  },
  {
    "plot_number": 872,
    "property_type": "Palacess"
  },
  {
    "plot_number": 873,
    "property_type": "Palacess"
  },
  {
    "plot_number": 874,
    "property_type": "Palacess"
  },
  {
    "plot_number": 875,
    "property_type": "Palacess"
  },
  {
    "plot_number": 876,
    "property_type": "Palacess"
  },
  {
    "plot_number": 877,
    "property_type": "Palacess"
  },
  {
    "plot_number": 878,
    "property_type": "Palacess"
  },
  {
    "plot_number": 879,
    "property_type": "Palacess"
  },
  {
    "plot_number": 880,
    "property_type": "commercial"
  },
  {
    "plot_number": 881,
    "property_type": "Commercial Residential"
  }
]

module.exports = propertyFileType;
