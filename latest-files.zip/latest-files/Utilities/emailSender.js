const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail", // or use your SMTP
  auth: {
    user: 'mouzamsaleem007@gmail.com',
    pass: 'usdtcdclgiiitgaq',
  },

  
});

//usdt cdcl giii tgaq

// youarenextbillionaire000

//kcef htxv qypb mvyd

// litg xdkv zdcf qooq

async function sendEmail(to, subject, html) {
  return await transporter.sendMail({
    from: `"Your Company Name" <${'mouzam.ali@dubizzlelabs.com'}>`,
    to,
    subject,
    html,
  });
}

module.exports = sendEmail;
