module.exports = {
    SUCCESS_CONTACT_CREATED: "Contact created successfully.",
    ERROR_MISSING_FIELDS: "Missing required fields.",
    ERROR_INTERNAL_SERVER: "Internal server error.",
    SUCCESS_CONTACT_FETCHED: "Contacts fetched successfully.",
  };