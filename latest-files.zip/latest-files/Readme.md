# documentation for al-Marina project 

# npm run dev

# http://localhost:5000/api/   path for get request


POST REQUEST FOR UPLOAD EXCEL FILE

LOCAL URL 


# http://localhost:8000/api/uploadData

# http://localhost:8000/api/getAlMarinaData


PRODUCTION URL

# https://erth-al-marina.zameengeomatics.com/api/getAlMarinaData